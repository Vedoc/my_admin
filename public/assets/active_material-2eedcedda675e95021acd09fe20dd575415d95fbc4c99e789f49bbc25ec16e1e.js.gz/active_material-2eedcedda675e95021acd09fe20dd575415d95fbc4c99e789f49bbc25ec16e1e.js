
import "active_material/actions-toggle"

document.querySelector('html').className += ' am-js';
